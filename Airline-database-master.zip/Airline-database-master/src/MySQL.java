import java.sql.*;

public class MySQL {
    private Connection mySqlConnection;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    public MySQL() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.getConnection("jdbc:mysql://localhost/java982?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
    }
    public void Create() throws SQLException {
        try{
           this.preparedStatement = this.mySqlConnection.prepareStatement("" +
                   "INSERT INTO users (username , password) VALUES (? , ?)");
           this.preparedStatement.setString(1,"Alex");
           this.preparedStatement.setString(2,"Alex456");
           this.preparedStatement.executeUpdate();

        }catch (SQLException throwables){
            throwables.printStackTrace();
        }
    }
    public static void main(String[] str) throws SQLException {
          MySQL mySQL = new MySQL();
          mySQL.Create();
    }

}
