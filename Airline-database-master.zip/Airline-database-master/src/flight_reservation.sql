-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2020 at 11:36 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flight_reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `airline`
--

CREATE TABLE `airline` (
  `AirlineID` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `cod` int(11) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `airport`
--

CREATE TABLE `airport` (
  `AirportID` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `code` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `ticketID` int(11) NOT NULL,
  `flightID` int(11) DEFAULT NULL,
  `SeatNum` varchar(11) DEFAULT NULL,
  `class` varchar(45) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `passengerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`ticketID`, `flightID`, `SeatNum`, `class`, `price`, `passengerID`) VALUES
(4, 7, '$34', 'N', 5423000, 7),
(5, 2, '$67', 'N', 5423000, 6),
(7, 2, '$19', 'N', 5423000, 6),
(8, 2, '$56', 'N', 5423000, 5),
(9, 2, '$44', 'N', 5423000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `flightID` int(11) NOT NULL,
  `pilotName` varchar(45) NOT NULL,
  `AirlineName` varchar(45) NOT NULL,
  `departureDate` date NOT NULL,
  `departureTime` time NOT NULL,
  `departureCity` varchar(45) NOT NULL,
  `arrivalCity` varchar(45) NOT NULL,
  `arrivalDate` date NOT NULL,
  `arrivalTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`flightID`, `pilotName`, `AirlineName`, `departureDate`, `departureTime`, `departureCity`, `arrivalCity`, `arrivalDate`, `arrivalTime`) VALUES
(1, 'Ali', 'Mahan', '2020-09-15', '12:45:13', 'Mashhad', 'Tehran', '2020-09-15', '13:33:45'),
(2, 'Arash razavi', 'Ghatar Airline', '2020-09-25', '10:34:12', 'Gheshm', 'Tehran', '2020-09-27', '09:18:00'),
(4, 'Iman Naderi', 'Ghatar Airline', '2020-10-02', '10:00:00', 'Dubai', 'Gheshm', '2020-11-25', '18:00:00'),
(7, 'ahmad amiri', 'Mahan', '2020-10-16', '19:06:28', 'Ahvaz', 'BandarAbas', '2020-10-18', '15:06:28'),
(8, 'Morteza Ahmadi', 'Homa', '2020-10-06', '08:08:17', 'Yazd', 'Mashhad', '2020-10-16', '12:08:17'),
(9, 'Mohamad Hosseini', 'IRANAIR', '2020-09-23', '10:12:25', 'Tabriz', 'Kermanshah', '2020-10-07', '20:00:00'),
(10, 'Mohamad Hosseini', 'IRANAIR', '2020-09-23', '10:12:25', 'Tabriz', 'Tehran', '2020-10-06', '23:00:00'),
(11, 'Naser Hamidi', 'GhatarAirline', '2020-09-23', '13:02:00', 'Istanbul', 'Tehran', '2020-09-16', '18:02:00'),
(12, 'Mohsen Rezaie', 'Mahan', '2020-09-09', '12:23:13', 'Tehran', 'Mashhad', '2020-10-10', '11:23:13'),
(13, 'Ali Godarzi', 'Mahan', '2020-09-08', '08:25:10', 'Tehran', 'Yazd', '2020-10-05', '16:25:10'),
(14, 'Ali Mosavi', 'IRANAIR', '2020-10-04', '12:26:37', 'Tehran', 'Tabriz', '2020-10-07', '16:26:37'),
(15, 'ahmad amiri', 'IRANAIR', '2020-09-08', '10:31:19', 'Tehran', 'Shiraz', '2020-09-30', '20:31:19'),
(16, 'Emad yazdani', 'Mahan', '2020-09-29', '17:32:16', 'Tehran', 'Esfahan', '2020-10-04', '18:32:16'),
(17, 'ahmad amiri', 'IRANAIR', '2020-10-01', '13:33:41', 'Tehran', 'BandarAbas', '2020-10-05', '16:33:41'),
(18, 'Naser Hamidi', 'Mahan', '2020-10-04', '08:34:46', 'Tehran', 'Kermanshah', '2020-09-09', '13:34:46');

-- --------------------------------------------------------

--
-- Table structure for table `flightsearch`
--

CREATE TABLE `flightsearch` (
  `FlightID` int(11) NOT NULL,
  `departureCity` varchar(45) NOT NULL,
  `departureDate` date NOT NULL DEFAULT current_timestamp(),
  `arrivalCity` varchar(45) NOT NULL,
  `arrivalDate` date NOT NULL DEFAULT current_timestamp(),
  `NumberOfPassengers` int(11) NOT NULL,
  `TwoWayFlight` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `PassengerID` int(11) NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `age` int(11) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`PassengerID`, `firstName`, `lastName`, `email`, `age`, `password`) VALUES
(1, 'faeghe', 'farrokhpey', 'faeghe.farrokhpey@yahoo.com', 28, '123456'),
(2, 'faeze', 'farrokhpey', 'faeze.fa@gmail.com', 30, '56789'),
(4, 'admin', 'admin', 'admin.admin@gmail.com', 12, 'adminAdmin'),
(5, 'reza', 'rezaie', 're.reza@gmail.com', 34, '2468'),
(6, 'sara', 'samadi', 'sara.ss@yahoo.com', 40, '898989'),
(7, 'mahtab', 'sabeti', 'sabeti.mh@gmail.com', 37, 'dd12345'),
(8, 'fateme', 'godarzi', 'Godarzi.fa@yahoo.com', 22, 'ff123456');

-- --------------------------------------------------------

--
-- Table structure for table `pilot`
--

CREATE TABLE `pilot` (
  `pilotID` int(11) NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `experience` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airline`
--
ALTER TABLE `airline`
  ADD PRIMARY KEY (`AirlineID`);

--
-- Indexes for table `airport`
--
ALTER TABLE `airport`
  ADD PRIMARY KEY (`AirportID`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`ticketID`),
  ADD KEY `passengerID` (`passengerID`),
  ADD KEY `flightID` (`flightID`);

--
-- Indexes for table `flight`
--
ALTER TABLE `flight`
  ADD PRIMARY KEY (`flightID`);

--
-- Indexes for table `flightsearch`
--
ALTER TABLE `flightsearch`
  ADD PRIMARY KEY (`FlightID`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`PassengerID`);

--
-- Indexes for table `pilot`
--
ALTER TABLE `pilot`
  ADD PRIMARY KEY (`pilotID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `airline`
--
ALTER TABLE `airline`
  MODIFY `AirlineID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `airport`
--
ALTER TABLE `airport`
  MODIFY `AirportID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `ticketID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `flight`
--
ALTER TABLE `flight`
  MODIFY `flightID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `flightsearch`
--
ALTER TABLE `flightsearch`
  MODIFY `FlightID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `passenger`
--
ALTER TABLE `passenger`
  MODIFY `PassengerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pilot`
--
ALTER TABLE `pilot`
  MODIFY `pilotID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`passengerID`) REFERENCES `passenger` (`PassengerID`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`flightID`) REFERENCES `flight` (`flightID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
