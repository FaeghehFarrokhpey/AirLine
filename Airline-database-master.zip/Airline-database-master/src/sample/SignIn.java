package sample;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import java.sql.*;

public class SignIn{

    public Connection mySqlConnection;
    public Statement statement;
    public ResultSet resultSet;
    public ResultSet FindUser;
    public PreparedStatement preparedStatement;
   public static int UserID;
   public static String UserFirstName;
   public static String UserLastName;
    Menu menu = new Menu();

    public SignIn() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }

    public void SignInLogin(){

        Image SignInIcon = new Image(getClass().getResourceAsStream("../images/flight-icon.png"));
        ImageView SignInIconView = new ImageView(SignInIcon);
        SignInIconView.setFitHeight(30);
        SignInIconView.setFitWidth(30);


        Main.mainWindow.setTitle("welcome To Login Page");
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.setPadding(new Insets(20));

        //Title Page
        Text LoginText = new Text("LoginIn");
        LoginText.setFill(Color.WHITE);
        LoginText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,28));
        LoginText.setTextAlignment(TextAlignment.CENTER);
        gridPane.add(LoginText, 0,0,4,1);

        //Set username
        Label username = new Label("Email Address: ");
        username.setId("text");
        username.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(username, 0,1);
        TextField usernameText = new TextField();
        gridPane.add(usernameText, 1,1);

        //Set password
        Label password = new Label("Password: ");
        password.setId("text");
        password.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(password,0,2);
        PasswordField passwordText = new PasswordField();
        gridPane.add(passwordText,1,2);

        //Button Login
        Image LoginIcon = new Image(getClass().getResourceAsStream("../images/flight-icon.png"));
        ImageView LoginIconView = new ImageView(LoginIcon);
        LoginIconView.setFitHeight(30);
        LoginIconView.setFitWidth(30);

        Button LoginButton = new Button("Login");
        LoginButton.setMaxWidth(150.0);
        LoginButton.setPrefWidth(150);
        LoginButton.setPrefHeight(40);
        LoginButton.setAlignment(Pos.CENTER);
        LoginButton.setId("btn_login");
        LoginButton.setGraphic(LoginIconView);
        gridPane.add(LoginButton,0,3);
        LoginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(validate(usernameText,passwordText)){
                    menu.SceneViewMenu();
                    usernameText.setText("");
                    passwordText.setText("");
                }else AlertBox.display("Error", "Incorrect email or password." +
                        "\nPlease try again!");

            }
        });
        // Title Page
        Text SignInText = new Text("SignIn");
        SignInText.setFill(Color.WHITE);
        SignInText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,28));
        gridPane.add(SignInText,0,5);

        // First Name
        Label firstName = new Label("FirstName: ");
        firstName.setId("text");
        firstName.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(firstName, 0,6);
        TextField inputFirstName = new TextField();
        gridPane.add(inputFirstName,1,6);

        //lastName
        Label lastName = new Label("LastName: ");
        lastName.setId("text");
        lastName.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(lastName, 2,6);
        TextField inputLastName = new TextField();
        gridPane.add(inputLastName,3,6);

        //Email
        Label Email = new Label("Email: ");
        Email.setId("text");
        Email.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(Email,0,7);
        TextField inputEmail = new TextField();
        gridPane.add(inputEmail, 1,7,3,1);

        //Age
        Label Age = new Label("Age: ");
        Age.setId("text");
        Age.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(Age,0,8);
        TextField inputAge = new TextField();
        gridPane.add(inputAge,1,8);

        //password
        Label Password = new Label("Password: ");
        Password.setId("text");
        Password.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(Password, 2,8);
        PasswordField inputPassword = new PasswordField();
        gridPane.add(inputPassword, 3,8);

        //Button for CreateAccount
        Button CreateAccount = new Button("CreateAccount");
        CreateAccount.setGraphic(SignInIconView);
        HBox hBoxCreate = new HBox(20);
        CreateAccount.setPrefWidth(200);
        CreateAccount.setPrefHeight(40);
        CreateAccount.setId("btn_login");
        hBoxCreate.setAlignment(Pos.CENTER);
        hBoxCreate.getChildren().add(CreateAccount);
        gridPane.add(hBoxCreate,0,9,4,1);

        //with click to Button show errorMessage if there is any error!
        CreateAccount.setOnAction(new EventHandler<ActionEvent>() {
            String errorMessage = "";
            @Override
            public void handle(ActionEvent event) {
                if (inputFirstName.getText().equals("")){ this.errorMessage += "The FirsName is required Field!\n"; }
                if (inputLastName.getText().equals("")){ this.errorMessage += "The LastName is required Field!\n"; }
                if (inputEmail.getText().equals("")){ this.errorMessage += "The Email is required Field!\n"; }
                if (inputAge.getText().equals("")){ this.errorMessage += "The Age is required Field!\n"; }
                if (inputPassword.getText().equals("")){ this.errorMessage += "The Password is required Field!\n"; }
                if(!errorMessage.equals("")) AlertBox.display("Error", errorMessage);
                else if(createAccount(inputFirstName, inputLastName, inputEmail, inputAge, inputPassword)){
                    AlertBox.display("Success", "Your new account has been created!"
                            + "\nPlease continue to log-in!");
                    inputFirstName.setText("");
                    inputLastName.setText("");
                    inputEmail.setText("");
                    inputAge.setText("");
                    inputPassword.setText("");
                }else AlertBox.display("Error", "Error creating account" +
                        "\nPlease check and try again!");
            }

        });

        Scene scene = new Scene(gridPane, 700, 500);
        scene.getStylesheets().add(SignIn.class.getResource("Login.css").toExternalForm());

        Main.mainWindow.setScene(scene);
        Main.mainWindow.show();
    }

    private  boolean  createAccount(TextField inputFirstName, TextField inputLastName, TextField inputEmail, TextField inputAge, TextField inputPassword){
        try{
            this.preparedStatement =this.mySqlConnection.prepareStatement("INSERT INTO passenger " +
                    "(firstName, lastName, email, age, password) VALUES (?, ?, ?, ?, ?)") ;
            this.preparedStatement.setString(1, inputFirstName.getText().trim());
            this.preparedStatement.setString(2, inputLastName.getText().trim());
            this.preparedStatement.setString(3, inputEmail.getText().trim());
            this.preparedStatement.setString(4, inputAge.getText().trim());
            this.preparedStatement.setString(5, inputPassword.getText().trim());
            this.preparedStatement.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        }
        return true;
    }


    private boolean validate (TextField username , PasswordField password){
        try {
            this.preparedStatement = this.mySqlConnection.prepareStatement("SELECT * from passenger where email  = ? AND password = ?");
            this.preparedStatement.setString(1,username.getText().trim());
            this.preparedStatement.setString(2,password.getText().trim());
            this.resultSet = this.preparedStatement.executeQuery();

            if (resultSet.next()){
                this.UserFirstName = this.resultSet.getString("firstName");
                this.UserLastName = this.resultSet.getString("lastName");
                this.UserID= this.resultSet.getInt("PassengerID");
                boolean getUser = true;
                AlertBox.display("Success",
                        "welcome Mrs/Mr "+ this.UserFirstName + this.UserLastName+" ! \n");
                Main.setID(this.UserID);
                return true;
            }



        }catch (SQLException e){e.printStackTrace();}
        return false;
    }

}
