package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import java.sql.*;
import java.util.concurrent.ThreadLocalRandom;

interface Booking {
    public void Book();
}

public class BookFlight implements Booking{
    public Connection mySqlConnection;
    public Statement statement;
    public ResultSet resultSet;
    public PreparedStatement preparedStatement;
    String FirstName = SignIn.UserFirstName;
    String LastName = SignIn.UserLastName;
    private String DepartureTime;
    private String ArrivalTime;
    private String DepartureDate;
    private String ArrivalDate;
    private int price = 5423000;
    private int flightID;
    ViewFlight viewFlight = new ViewFlight();


    public BookFlight(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }

    @Override
    public void Book() {
        try{
            this.preparedStatement = this.mySqlConnection.prepareStatement("SELECT * from flight where departureCity  = ? AND arrivalCity = ?");
            this.preparedStatement.setString(1, Flights.DepCity);
            this.preparedStatement.setString(2, Flights.ArrCity);
            this.resultSet = this.preparedStatement.executeQuery();
            while (resultSet.next()){
              this.DepartureTime = this.resultSet.getString("departureTime");
              this.ArrivalTime = this.resultSet.getString("arrivalTime");
              this.DepartureDate = this.resultSet.getString("departureDate");
              this.ArrivalDate = this.resultSet.getString("arrivalDate");
              this.flightID = this.resultSet.getInt("flightID");

            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        Main.mainWindow.setTitle("Thank You for your Selection!");
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(20);
        gridPane.setHgap(20);
        gridPane.setPadding(new Insets(20));

        //User Information
        Text FlightText = new Text(FirstName+ " " + LastName + " you select : ");
        FlightText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        //gridPane.add(FlightText, 0,0);
        FlightText.setFill(Paint.valueOf("#fff"));

        // Show Departure City and Arrival City
        Text FlightCity = new Text("One Way Flight ("+Flights.DepCity + " "+"To"+" "+Flights.ArrCity+ ")");
        FlightCity.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,20));
        FlightCity.setFill(Paint.valueOf("#fff"));
        //gridPane.add(FlightCity, 1,0);
        HBox BOXINFO = new HBox(20);
        BOXINFO.setAlignment(Pos.CENTER);
        BOXINFO.getChildren().addAll(FlightText, FlightCity);
        gridPane.add(BOXINFO, 0,1,4,1);

        // Show Departure Time and Arrival Time
            Image TimeImage = new Image(getClass().getResourceAsStream("../images/FlightTime-icon.png"));
            ImageView TimePic = new ImageView(TimeImage);
            TimePic.setFitHeight(40);
            TimePic.setFitWidth(40);

            Text FlightTime = new Text(DepartureTime+ "--"+ ArrivalTime);
            FlightTime.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
            FlightTime.setFill(Paint.valueOf("#fff"));
            HBox TimeBox = new HBox(20);
            TimeBox.setAlignment(Pos.CENTER);
            TimeBox.getChildren().addAll(TimePic, FlightTime);

            gridPane.add(TimeBox,0,2);

        //Show Departure Date and Arrival Date

        Text FlightDepDate = new Text(this.DepartureDate);
        FlightDepDate.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        FlightDepDate.setFill(Paint.valueOf("#fff"));

        Image DateImage = new Image(getClass().getResourceAsStream("../images/airplane.png"));
        ImageView DatePic = new ImageView(DateImage);
        DatePic.setFitHeight(40);
        DatePic.setFitWidth(40);

        Text FlightArrDate = new Text(this.ArrivalDate);
        FlightArrDate.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        FlightArrDate.setFill(Paint.valueOf("#fff"));

        HBox DateBox = new HBox(20);
        DateBox.setAlignment(Pos.CENTER);
        DateBox.getChildren().addAll(FlightDepDate,DatePic,FlightArrDate);

        gridPane.add(DateBox,1,2);

        String PassengerNumber = String.valueOf(Flights.PassNumber);
        Text Price = new Text("Price: "+PassengerNumber+" "+ "*"+ "54,23,000");
        Price.setFill(Paint.valueOf("#fff"));
        Price.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(Price,2,2);

        //Text for Attention
        Text Attention = new Text("In the wake of the novel coronavirus (COVID-19), several airlines have waived change \n" +
                "fees and updated refund policies. If you have travel plans in the coming months, it's likely no fees \n" +
                "will apply to make a one-time change in plans. If you would like to cancel and your airline isn't \n" +
                "offering a full cash refund at this time, it's best to wait as long as possible to see if your flight gets \n" +
                "canceled as airlines are adjusting schedules drastically in this uncertain time. For more tips to \n" +
                "get a refund for flights canceled due to COVID-19, read this guide.");
        Attention.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        Attention.setFill(Paint.valueOf("#fff"));
        gridPane.add(Attention,0,4,4,1);

        //Button
        HBox BOXBtn = new HBox(20);
        BOXBtn.setAlignment(Pos.CENTER);

        Button SelectButton = new Button("Ticket Selection");
        SelectButton.setPrefWidth(200);
        SelectButton.setPrefHeight(40);
        SelectButton.setId("button");
        Button BackButton = new Button("Back to Selection");
        BackButton.setPrefWidth(200);
        BackButton.setPrefHeight(40);
        BackButton.setId("button");
        //Action for Button
        BackButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                viewFlight.start();
            }
        });

        SelectButton.setOnAction(new EventHandler<ActionEvent>() {
            String errorMessage = "";
            @Override
            public void handle(ActionEvent event) {
                AddINFORMATION();
                AlertBox.display("Success", "An email will be sent to you to pay the flight cost!\n" +
                        "If you have any question please call us!");
                viewFlight.start();
            }
        });

        BOXBtn.getChildren().addAll(SelectButton,BackButton);
        gridPane.add(BOXBtn,0,5,4,1);


        Scene scene = new Scene(gridPane, 700, 500);
        scene.getStylesheets().add(Booking.class.getResource("BookFlight.css").toExternalForm());
        Main.mainWindow.setScene(scene);
        Main.mainWindow.show();
    }
    public void AddINFORMATION(){
        int randomNumber = ThreadLocalRandom.current().nextInt(1,100);
        String SeatNumber = "$"+String.valueOf(randomNumber);
        int FinalPrice = Flights.PassNumber * this.price;
        try{
            this.preparedStatement = this.mySqlConnection.prepareStatement("INSERT INTO booking " +
                    "(flightID, SeatNum, class, price, passengerID) VALUES (?, ?, ?, ?, ?)") ;
            this.preparedStatement.setInt(1, this.flightID);
            this.preparedStatement.setString(2, SeatNumber);
            this.preparedStatement.setString(3, "N");
            this.preparedStatement.setInt(4, FinalPrice);
            this.preparedStatement.setInt(5, SignIn.UserID);
            this.preparedStatement.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
}
