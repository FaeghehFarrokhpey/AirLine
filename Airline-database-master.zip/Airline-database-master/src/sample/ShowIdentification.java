package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.*;

public class ShowIdentification {
    private Connection mySqlConnection;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;


    public ShowIdentification(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }
    public static void display() {
        ShowIdentification showIdentification = new ShowIdentification();
        FlightInformation flightInformation = new Flight();
        Stage window = new Stage();

        //Block events to other windows
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Message");
        window.setMinWidth(350);
        window.setMinHeight(200);
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(20);
        gridPane.setHgap(20);
        gridPane.setPadding(new Insets(20));

        Label UserNameLabel = new Label("Email: ");
        UserNameLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(UserNameLabel, 0, 0);
        TextField UserNameInput = new TextField();
        gridPane.add(UserNameInput, 1,0);

        Label PasswordLabel = new Label("password: ");
        PasswordLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(PasswordLabel, 0, 2);
        TextField passwordInput = new TextField();
        gridPane.add(passwordInput, 1,2);

        Button AcceptButton = new Button("Login");
        AcceptButton.setPrefWidth(150);
        AcceptButton.setPrefHeight(40);
        AcceptButton.setAlignment(Pos.CENTER);
        gridPane.add(AcceptButton,0,3);
        AcceptButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                window.close();
                if(showIdentification.CheckUser()) {
                   // System.out.println("Heloooo");
                    flightInformation.flight();
                }
            }
        });
        Scene scene = new Scene(gridPane);
        window.setScene(scene);
        window.showAndWait();
    }
    private boolean CheckUser(){
        try {
            this.preparedStatement = this.mySqlConnection.prepareStatement("SELECT * from passenger WHERE email  = ? ");
            this.preparedStatement.setString(1,"admin.admin@gmail.com");
            //this.preparedStatement.setString(2,"adminAdmin");
            this.resultSet = this.preparedStatement.executeQuery();
            if(resultSet.next()){
                return true;
            }


        }catch (SQLException e){
            e.printStackTrace();
        }
        return true;
    }
}
