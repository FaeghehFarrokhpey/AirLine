package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.layout.BorderPane;
import sample.Test.cancel;
import javafx.scene.layout.VBox;
import java.sql.*;

public class CancelFlight extends BorderPane{
    Menu menu = new Menu();
    public Connection mySqlConnection;
    public Statement statement;
    public ResultSet resultSet;
    public PreparedStatement preparedStatement;
    public int FlightId;
    TableView<cancel> TableUser;

    public CancelFlight(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }
    public void cancel(){
        Main.mainWindow.setTitle("Cancel Flight ");
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);


        Label airlineLabel = new Label();
        airlineLabel.setFont(new Font(18));
        airlineLabel.setText("cancel Flight");
        gridPane.add(airlineLabel, 0,0,4,1);

        Text name = new Text(SignIn.UserFirstName+" "+SignIn.UserLastName+ " "+"your Flight List:");
        name.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        name.setFill(Paint.valueOf("#fff"));
        gridPane.add(name, 0,1,4,1);

        //++++++++++++++++++++++++Table++++++++++++++++++++++//
        TableColumn<cancel, String> departureCity = new TableColumn<>("departure City");
        departureCity.setMinWidth(100);
        departureCity.setCellValueFactory(new PropertyValueFactory<>("departureCity"));

        TableColumn<cancel, String> arrivalCity = new TableColumn<>("arrival City");
        arrivalCity.setMinWidth(100);
        arrivalCity.setCellValueFactory(new PropertyValueFactory<>("arrivalCity"));

        TableColumn<cancel, String> arrivalDate = new TableColumn<>("arrival Date");
        arrivalDate.setMinWidth(90);
        arrivalDate.setCellValueFactory(new PropertyValueFactory<>("arrivalDate"));

        TableColumn<cancel, Integer> price = new TableColumn<>("price");
        price.setMinWidth(90);
        price.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<cancel, Button> action = new TableColumn<>("Action");
        action.setMinWidth(120);
        action.setCellValueFactory(new PropertyValueFactory<>("action"));

        TableUser = new TableView<>();
        TableUser.setPlaceholder(new Label("No flight found"));
        TableUser.getColumns().addAll(departureCity, arrivalCity, arrivalDate, price, action);
        VBox vBox = new VBox();

        //Add Button on bottom

        Button backButton = new Button("BACK");
        backButton.setPrefWidth(150);
        backButton.setPrefHeight(35);
        backButton.setId("button");
        backButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                menu.SceneViewMenu();
            }
        });
        HBox hBox = new HBox(5);
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().addAll(backButton);


        vBox.getChildren().addAll(airlineLabel ,name, TableUser, hBox);
        setCenter(vBox);
        setAlignment(vBox, Pos.CENTER);
        setMargin(vBox, new Insets(20,20,0,20));

        Scene scene = new Scene(gridPane, 950, 500);
        gridPane.add(name, 0, 0,4,1);
        gridPane.add(TableUser, 0, 1, 4,1);
        gridPane.add(hBox, 0,2,4,1);
        setMargin(gridPane, new Insets(0,20,20,10));

        //++++++++++++++++++++++++++++++++++set prepareStatement+++++++++++++++++++++++++++++++++//

        try{
            this.preparedStatement = this.mySqlConnection.prepareStatement("SELECT * FROM booking WHERE " +
                    "passengerID = ?");
            this.preparedStatement.setInt(1, SignIn.UserID);
            this.resultSet = this.preparedStatement.executeQuery();
            while (resultSet.next()) {
                 this.FlightId = this.resultSet.getInt(2);
                Button btnCancel = new Button("cancel flight");
                btnCancel.setId("button");
                btnCancel.setPrefWidth(100);
                btnCancel.setUserData(resultSet.getInt(1));

                this.preparedStatement = this.mySqlConnection.prepareStatement("SELECT * FROM flight " +
                        "WHERE flightID = ?");
                this.preparedStatement.setInt(1, this.FlightId);
                ResultSet flightShow = this.preparedStatement.executeQuery();
                flightShow.next();
                TableUser.getItems().add(
                        new cancel(flightShow.getString(6), flightShow.getString(7),
                                flightShow.getDate(8), resultSet.getInt(5), btnCancel)
                );
                btnCancel.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        String errorMessage = "";
                       if(Delete()){
                            AlertBox.display("success", "this Flight is delete successfully!");
                            menu.SceneViewMenu();
                       }else {
                           AlertBox.display("error", "please try again later!");
                       }
                    }
                });
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

        CancelFlight cancelFlight = new CancelFlight();
        Main.mainWindow.setScene(scene);
        scene.getStylesheets().add(CancelFlight.class.getResource("CancelFlight.css").toExternalForm());
        // bootstrap the stage
        Main.mainWindow.show();

    }
    public boolean Delete(){
        try{
            this.preparedStatement = this.mySqlConnection.prepareStatement("DELETE FROM booking " +
                    "WHERE flightID = ? ");
            this.preparedStatement.setInt(1, this.FlightId);
            this.preparedStatement.executeUpdate();
            return true;
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
}
