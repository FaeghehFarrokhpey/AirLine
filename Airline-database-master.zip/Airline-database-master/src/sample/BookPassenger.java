package sample;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import sample.Test.passenger;
import java.sql.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;


public class BookPassenger extends BorderPane{
    Menu menu = new Menu();
    SignIn signIn = new SignIn();

    public Connection mySqlConnection;
    public Statement statement;
    public ResultSet resultSet;
    public PreparedStatement preparedStatement;
    private static Stage mainWindow = null;
    private static int flightID = 0;
    static Scene flightResultContScene;
    TableView<passenger> passengerTable;
    public BookPassenger() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }
    public void Passengers(){
        Label menuLabel = new Label();
        menuLabel.setText("Welcome Flight attendant");
        menuLabel.setFont(new Font(25));
        menuLabel.setPadding(new Insets(0,0,10,0));

        TableColumn<passenger, String> SeatNumber = new TableColumn<>("SeatNumber");
        SeatNumber.setMinWidth(90);
        SeatNumber.setCellValueFactory(new PropertyValueFactory<>("SeatNumber"));

        TableColumn<passenger, String> fistName = new TableColumn<>("fistName");
        fistName.setMinWidth(100);
        fistName.setCellValueFactory(new PropertyValueFactory<>("fistName"));

        TableColumn<passenger, String> lastName = new TableColumn<>("lastName");
        lastName.setMinWidth(100);
        lastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));



        passengerTable = new TableView<>();
        passengerTable.setPlaceholder(new Label("No Passenger Exist!!"));
        passengerTable.getColumns().addAll( SeatNumber, fistName, lastName);
        VBox vBox = new VBox();
        vBox.getChildren().addAll(menuLabel, passengerTable);

        Button backButton = new Button("BACK");
        backButton.setPrefWidth(100);
        backButton.setPrefHeight(35);
        backButton.setId("button");
        backButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                menu.SceneViewMenu();
            }
        });

        Button cancelButton = new Button("CANCEL SELECTED FLIGHT");
        cancelButton.setPrefWidth(180);
        cancelButton.setPrefHeight(35);
        cancelButton.setId("button");

        HBox hBox = new HBox(5);
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().addAll(backButton, cancelButton);

        setCenter(vBox);
        setAlignment(vBox, Pos.CENTER);
        setMargin(vBox, new Insets(0,20,0,20));

        Main.mainWindow.setTitle("Book Passengers ");
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        Scene scene = new Scene(grid, 950, 500);
        grid.add(menuLabel, 0, 0,4,1);
        grid.add(passengerTable, 0, 1, 4,1);
        grid.add(hBox, 0,2,4,1);
        setMargin(grid, new Insets(0,20,20,10));
        /*=======================================================================================
                                    Set PrepareStatement
        =========================================================================================
         */
        String errorMessage = "";
            try{
                this.preparedStatement = this.mySqlConnection.prepareStatement("SELECT * FROM booking");
                this.resultSet = this.preparedStatement.executeQuery();


                while (resultSet.next()){
                    int UserID = this.resultSet.getInt(6);
                    this.preparedStatement = this.mySqlConnection.prepareStatement("SELECT * FROM " +
                            "passenger WHERE PassengerID = ?");
                    this.preparedStatement.setInt(1, UserID);
                    ResultSet userSet = this.preparedStatement.executeQuery();
                    userSet.next();
                    passengerTable.getItems().add(
                          new passenger( resultSet.getString(3), userSet.getString(2)
                                  ,userSet.getString(3))
                           );
                }

            }catch (SQLException e){
                e.printStackTrace();
            }
        /*=====================================================
        ===============================================================================
         */
        BookPassenger bookPassenger = new BookPassenger();
        Main.mainWindow.setScene(scene);
        scene.getStylesheets().add(BookPassenger.class.getResource("BookPassenger.css").toExternalForm());
        // bootstrap the stage
        Main.mainWindow.show();
    }
}
