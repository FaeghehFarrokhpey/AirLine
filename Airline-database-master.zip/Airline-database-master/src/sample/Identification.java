package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;

interface FlightInformation{
    public void flight();
}
class Flight implements FlightInformation{

    private Connection mySqlConnection;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;

    private DatePicker checkInDatePicker;
    private DatePicker checkInDatePickerArrival;
    Menu menu = new Menu();
    public Flight(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }


    @Override
    public void flight() {


        Main.mainWindow.setTitle("Flight time setting page");
        GridPane gridPane = new GridPane();
        // gridPane set
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(20);
        gridPane.setHgap(20);
        gridPane.setPadding(new Insets(20));
        //PageTitle
        Text FlightText = new Text("Flight Time Set");
        FlightText.setFill(Paint.valueOf("#fff"));
        FlightText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,25));
        gridPane.add(FlightText, 0,0);

        //Pilot Name Label
        Label pilotNameLabel = new Label("Pilot Name: ");
        pilotNameLabel.setId("labelColor");
        pilotNameLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,13));
        gridPane.add(pilotNameLabel, 0, 1);
        TextField PilotNameInput = new TextField();
        gridPane.add(PilotNameInput, 1,1);
        //FlightName
        Label AirlineNameLabel = new Label("Airline Name: ");
        AirlineNameLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,13));
        AirlineNameLabel.setId("labelColor");
        gridPane.add(AirlineNameLabel,2,1);
        TextField AirlineNameInput = new TextField();
        gridPane.add(AirlineNameInput,3,1);

        //departureCity
        Label departureCityLabel = new Label("departure City: ");
        departureCityLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,13));
        departureCityLabel.setId("labelColor");
        gridPane.add(departureCityLabel, 0, 2);
        TextField departureCityInput = new TextField();
        gridPane.add(departureCityInput, 1,2,3,1);

        //arrivalCity
        Label arrivalCityLabel = new Label("Arrival City: ");
        arrivalCityLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,13));
        arrivalCityLabel.setId("labelColor");
        gridPane.add(arrivalCityLabel, 0, 3);
        TextField arrivalCityInput = new TextField();
        gridPane.add(arrivalCityInput, 1,3,3,1);
        // departureDate Label
        Text departureDateText = new Text("departureDate: ");
        departureDateText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,13));
        departureDateText.setFill(Paint.valueOf("#fff"));
        gridPane.add(departureDateText, 0,4);
        checkInDatePicker = new DatePicker();
        gridPane.add(checkInDatePicker, 1, 4);

        //departureTime input
        Label departureTimeText = new Label("departureTime: ");
        departureTimeText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,13));
        departureTimeText.setId("labelColor");
        gridPane.add(departureTimeText,2,4);
        HBox hBoxDeparture = new HBox(5);
        hBoxDeparture.setAlignment(Pos.BOTTOM_LEFT);
        TextField departureHour = new TextField();
        departureHour.setPrefWidth(40);
        Text hourText = new Text(":");
        TextField departureMinutes = new TextField();
        departureMinutes.setPrefWidth(40);
        Text minutesText = new Text(":");
        TextField departureSecond = new TextField();
        departureSecond.setPrefWidth(40);
        hBoxDeparture.getChildren().addAll(departureHour, hourText, departureMinutes, minutesText, departureSecond);
        gridPane.add(hBoxDeparture,3,4);

        //arrivalDate
        Text arrivalDateText = new Text("arrivalDate: ");
        arrivalDateText.setFill(Paint.valueOf("#fff"));
        arrivalDateText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,13));
        gridPane.add(arrivalDateText, 0,5);
        checkInDatePickerArrival = new DatePicker();
        gridPane.add(checkInDatePickerArrival, 1, 5);

        //arrivalTime input
        Label arrivalTimeText = new Label("arrivalTime: ");
        arrivalTimeText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,13));
        arrivalTimeText.setId("labelColor");
        gridPane.add(arrivalTimeText,2,5);
        HBox hBoxArrival = new HBox(5);
        hBoxArrival.setAlignment(Pos.BOTTOM_LEFT);
        TextField arrivalHour = new TextField();
        arrivalHour.setPrefWidth(40);
        Text hourTextArrival = new Text(":");
        TextField arrivalMinutes = new TextField();
        arrivalMinutes.setPrefWidth(40);
        Text minutesTextArrival = new Text(":");
        TextField arrivalSecond = new TextField();
        arrivalSecond.setPrefWidth(40);
        hBoxArrival.getChildren()
                .addAll(arrivalHour, hourTextArrival, arrivalMinutes , minutesTextArrival, arrivalSecond);
        gridPane.add(hBoxArrival,3,5);

        //Set Button
        HBox hBox =new HBox(5);
        hBox.setAlignment(Pos.CENTER);
        Button SetButton = new Button("Set Flight");
        SetButton.setPrefWidth(150);
        SetButton.setPrefHeight(35);
        SetButton.setId("button");
        Button ClearButton = new Button("Clear Flight");
        ClearButton.setPrefWidth(150);
        ClearButton.setPrefHeight(35);
        ClearButton.setId("button");
        Button BackButton = new Button("Back To Menu");
        BackButton.setPrefWidth(150);
        BackButton.setPrefHeight(35);
        BackButton.setId("button");
        hBox.getChildren().addAll(BackButton, SetButton, ClearButton);
        gridPane.add(hBox,0,6,4,1);
        //SetOnAction For Button
        SetButton.setOnAction(new EventHandler<ActionEvent>() {
            String errorMessage ="";
            @Override
            public void handle(ActionEvent event) {
                if(departureCityInput.getText().equals("")){
                    this.errorMessage += "Please Fill departure field!\n";
                }
                if(AirlineNameInput.getText().equals("")){
                    this.errorMessage += "Airline company Name is required Field!\n";
                }
                if(arrivalCityInput.getText().equals("")){
                    this.errorMessage += "Please Fill arrival field!\n";
                }
                if(checkInDatePicker.getValue().equals("")){
                    this.errorMessage += "Departure Date is required Field!\n";
                }
                if(departureHour.getText().equals("")){
                    this.errorMessage += "Hour of flight departure is required Field!\n";
                }
                if(departureMinutes.getText().equals("")){
                    this.errorMessage += "Minute of flight departure  is required Field!\n";
                }
                if(departureSecond.getText().equals("")){
                    this.errorMessage += "Second of flight departure  is required Field!\n";
                }
                if(checkInDatePickerArrival.getValue().equals("")){
                    this.errorMessage += "Arrival Date is required Field!\n";
                }
                if(arrivalHour.getText().equals("")){
                    this.errorMessage += "Hour of flight arrival is required Field!\n";
                }
                if(arrivalMinutes.getText().equals("")){
                    this.errorMessage += "Minute of flight arrival is required Field! \n";
                }
                if(arrivalSecond.getText().equals("")){
                    this.errorMessage += "Second of flight arrival is required Field \n";
                }
                if(!errorMessage.equals("")) AlertBox.display("Error", errorMessage);
                else if (createFlight(PilotNameInput, AirlineNameInput,departureCityInput,arrivalCityInput, departureHour, departureMinutes, departureSecond, checkInDatePicker, arrivalHour, arrivalMinutes, arrivalSecond, checkInDatePickerArrival)){
                    AlertBox.display("Success", "Flight time was adjusted successfully!\n");
                    PilotNameInput.setText("");
                    AirlineNameInput.setText("");
                    departureHour.setText("");
                    departureMinutes.setText("");
                    departureSecond.setText("");
                    arrivalHour.setText("");
                    arrivalMinutes.setText("");
                    arrivalSecond.setText("");
                    checkInDatePicker.setValue(LocalDate.parse(""));
                    checkInDatePickerArrival.setValue(LocalDate.parse(""));
                }else AlertBox.display("Error", "Error Set Flight" +
                        "\nPlease Try again");

            }
        });
        BackButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                menu.SceneViewMenu();
            }
        });
        //Scene
        Scene scene = new Scene(gridPane, 700, 500);
        scene.getStylesheets().add(Flight.class.getResource("Identification.css").toExternalForm());
        Main.mainWindow.setScene(scene);
        Main.mainWindow.show();
    }
    private boolean createFlight(TextField PilotName, TextField NameInput,TextField dCity,TextField aCity, TextField departureHour, TextField departureMinute, TextField departureSecond,DatePicker date1, TextField arrivalHour, TextField arrivalMinute, TextField arrivalSecond, DatePicker date2){
        int dHour = Integer.parseInt(departureHour.getText());
        int dMinute = Integer.parseInt(departureMinute.getText());
        int dSecond = Integer.parseInt(departureSecond.getText());
        LocalTime departureTime = LocalTime.of(dHour, dMinute, dSecond);
        int aHour = Integer.parseInt(arrivalHour.getText());
        int aMinute = Integer.parseInt(arrivalMinute.getText());
        int aSecond = Integer.parseInt(arrivalSecond.getText());
        LocalTime arrivalTime = LocalTime.of(aHour, aMinute, aSecond);
        try{
            this.preparedStatement = this.mySqlConnection.prepareStatement("INSERT INTO flight " +
                    "(pilotName, AirlineName, departureDate, departureTime,departureCity, arrivalCity," +
                    " arrivalDate, arrivalTime)" +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            this.preparedStatement.setString(1, PilotName.getText().trim());
            this.preparedStatement.setString(2, NameInput.getText().trim());
            this.preparedStatement.setString(3, String.valueOf(date1.getValue()));
            this.preparedStatement.setString(4, String.valueOf(departureTime));
            this.preparedStatement.setString(5, dCity.getText().trim());
            this.preparedStatement.setString(6, aCity.getText().trim());
            this.preparedStatement.setString(7, String.valueOf(date2.getValue()));
            this.preparedStatement.setString(8, String.valueOf(arrivalTime));
            this.preparedStatement.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        }
        return true;
    }
}

//abstract class BookFlights implements FlightInformation{
//    protected FlightInformation flightInformation;
//    public BookFlights(FlightInformation flightInformation){
//        this.flightInformation = flightInformation;
//    }
//    public void flight(){
//        this.flightInformation.flight();
//    }
//}
//class CreateFlight extends BookFlights{
//
//    public CreateFlight(FlightInformation flightInformation) {
//        super(flightInformation);
//    }
//    public void flight(){
//
//    }
//}
