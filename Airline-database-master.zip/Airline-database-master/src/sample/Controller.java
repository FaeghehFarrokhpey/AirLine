package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.*;

public class Controller {
    public Connection mySqlConnection;
    public Statement statement;
    public ResultSet resultSet;
    public ResultSet FindUser;
    public PreparedStatement preparedStatement;
    public Controller(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }
    public static void display(String status, String message) {

        Stage window = new Stage();
        GridPane gridPane = new GridPane();
        gridPane.setVgap(20);
        gridPane.setHgap(20);
        //Block events to other windows
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Message");
        window.setMinWidth(400);
        window.setMinHeight(400);

        Label label = new Label();
        label.setText("One Way Flight " + message);
        label.setFont(new Font(18));
        gridPane.add(label, 0,0,3,1);

        HBox FirstRBox =new HBox(15);

        Text depDate = new Text(Flights.DepDate.toString());
         depDate.setFont(new Font(16));

         Text ArrDate = new Text(Flights.ArrDate.toString());
         ArrDate.setFont(new Font(16));

         Text ArrTime = new Text("Show Time");
         ArrTime.setFont(new Font(16));

         Text Attention = new Text("NoN Stop!!");
         Attention.setFont(new Font(16));

        FirstRBox.getChildren().addAll(depDate, ArrDate, ArrTime, Attention);
        FirstRBox.setAlignment(Pos.CENTER);
        gridPane.add(FirstRBox,0,1);

         HBox SecondRBox = new HBox(15);

         Text textPrice = new Text("Price:");
         textPrice.setFont(new Font(17));

         Text Price = new Text("54,23,000");
         Price.setFont(new Font(17));

         SecondRBox.getChildren().addAll(textPrice,Price);
         SecondRBox.setAlignment(Pos.CENTER);
         gridPane.add(SecondRBox,0,2);

        Text Condition = new Text("Refundable according to the terms and conditions");
        Condition.setFont(new Font(16));
        gridPane.add(Condition, 0,3);

        Button accept = new Button("Select Ticket And Continue");
        accept.setAlignment(Pos.CENTER);
        accept.setPrefWidth(200);
        accept.setPrefHeight(50);
        HBox hBox = new HBox(5);
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().add(accept);
        gridPane.add(hBox,0,5);

        accept.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Booking booking = new BookFlight();
                window.close();
                booking.Book();

            }
        });

        if(status.equals("Error"))
            label.setTextFill(Color.RED);
        else label.setTextFill(Color.GREEN);

        Button closeButton = new Button();
        closeButton.setText("Close");
        closeButton.setAlignment(Pos.CENTER);
        closeButton.setOnAction(e -> window.close());

        VBox layout = new VBox(10);
        layout.getChildren().addAll(gridPane, closeButton);
        layout.setAlignment(Pos.CENTER);

        //Display window and wait for it to be closed before returning
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();



    }//display

}

