package sample;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.sql.*;

public class Menu extends Parent {
    private static Stage mainWindow= null;

    private Connection mySqlConnection;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;

    public Menu(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }
    public void SceneViewMenu(){
        Main.mainWindow.setTitle("Menu");
        SignIn signInPage = new SignIn();
        CancelFlight cancelFlight = new CancelFlight();
        FlightInformation flightInformation = new Flight();
        GridPane gridPane = new GridPane();
        Flight flight = new Flight();
        FlightSearch Search = new Flights();
        Menu menu = new Menu();
        BookPassenger bookPassenger = new BookPassenger();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(15);
        gridPane.setHgap(15);
        gridPane.setPadding(new Insets(20));
        HBox TopMenu = new HBox(30);
        HBox BottomMenu = new HBox(30);

        Image PassengersIcon = new Image(getClass().getResourceAsStream("../images/passengers-icon.png"));
        ImageView PassengersIconView = new ImageView(PassengersIcon);
        PassengersIconView.setFitHeight(30);
        PassengersIconView.setFitWidth(30);
        Button Book_Passenger = new Button("BookPassenger");
        Book_Passenger.setMaxWidth(200);
        Book_Passenger.setPrefWidth(200);
        Book_Passenger.setPrefHeight(40);
        Book_Passenger.setId("Menu_btn");
        Book_Passenger.setGraphic(PassengersIconView);
        Book_Passenger.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //here for BookPassenger
                if(SignIn.UserFirstName.equals("admin") && SignIn.UserLastName.equals("admin")){
                    bookPassenger.Passengers();
                }
                else {
                    AlertBox.display("Error","Access Deny to this page Sorry!!");
                    menu.SceneViewMenu();
                }
            }
        });


        Image CancelFlightIcon = new Image(getClass().getResourceAsStream("../images/cancel-icon.png"));
        ImageView CancelFlightIconView = new ImageView(CancelFlightIcon);
        CancelFlightIconView.setFitHeight(30);
        CancelFlightIconView.setFitWidth(30);
        Button Remove_Passenger = new Button("Cancel Flight");
        Remove_Passenger.setMaxWidth(200);
        Remove_Passenger.setPrefWidth(200);
        Remove_Passenger.setPrefHeight(40);
        Remove_Passenger.setId("Menu_btn");
        Remove_Passenger.setGraphic(CancelFlightIconView);
        Remove_Passenger.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //here for RemovePassenger
                cancelFlight.cancel();
            }
        });


        Image IdentificationIcon = new Image(getClass().getResourceAsStream("../images/iden-icon.png"));
        ImageView IdentificationIconView = new ImageView(IdentificationIcon);
        IdentificationIconView.setFitHeight(30);
        IdentificationIconView.setFitWidth(30);
        Button Identification = new Button("Identification");
        Identification.setMaxWidth(200);
        Identification.setPrefWidth(200);
        Identification.setPrefHeight(40);
        Identification.setId("Menu_btn");
        Identification.setGraphic(IdentificationIconView);
        Identification.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(SignIn.UserFirstName.equals("admin") && SignIn.UserLastName.equals("admin")){
                    flightInformation.flight();
                }
                else {
                    AlertBox.display("Error","Access Deny to this page Sorry!!");
                    menu.SceneViewMenu();
                }
            }
        });


        Image SearchIcon = new Image(getClass().getResourceAsStream("../images/flights-icon.png"));
        ImageView SearchIconView = new ImageView(SearchIcon);
        SearchIconView.setFitHeight(30);
        SearchIconView.setFitWidth(30);
        Button SearchUser = new Button("Search Flight");
        SearchUser.setMaxWidth(200);
        SearchUser.setPrefWidth(200);
        SearchUser.setPrefHeight(40);
        SearchUser.setId("Menu_btn");
        SearchUser.setGraphic(SearchIconView);
        SearchUser.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Search.flightSearch();

            }
        });
        TopMenu.getChildren().addAll(Book_Passenger, Remove_Passenger);
        TopMenu.setAlignment(Pos.CENTER);
        BottomMenu.getChildren().addAll( Identification, SearchUser);
        BottomMenu.setAlignment(Pos.CENTER);
        gridPane.add(TopMenu, 0,0 ,4,1);
        gridPane.add(BottomMenu, 0,1,4,1);
        Scene scene = new Scene(gridPane, 700, 500);
        scene.getStylesheets().add(Menu.class.getResource("Menu.css").toExternalForm());
        Main.mainWindow.setScene(scene);
        Main.mainWindow.show();
    }

}
