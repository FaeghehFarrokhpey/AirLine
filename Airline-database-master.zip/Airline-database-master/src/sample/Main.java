package sample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.*;


public class Main extends Application {
    private Connection mySqlConnection;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    private static int userID;

    static Stage mainWindow;
    static Scene menuScene;
    // private Object Menu;
    Menu menu = new Menu();
    SignIn signIn = new SignIn();
    public Main(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }

    }
    @Override
    public void start(Stage primaryStage){

        Main main = new Main();
        final boolean[] Loop = {false};
        mainWindow = primaryStage;
        mainWindow.setTitle("SEK Airline System");
        signIn.SignInLogin();
        mainWindow.show();
    }


    public static void main(String[] args) {
        launch(args);
    }

    public static void setID(int num){
        userID = num;
    }

}

