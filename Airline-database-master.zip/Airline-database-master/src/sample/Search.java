package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;

interface FlightSearch{
    public void flightSearch();
}
class Flights implements FlightSearch{
    private Connection mySqlConnection;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    private DatePicker checkInDatePickerDeparture;
    private DatePicker checkInDatePickerArrival;
    public static String DepCity = null;
    public static String ArrCity = null;
    public static LocalDate DepDate = null;
    public static LocalDate ArrDate = null;
    public static Time DepTime;
    public static Time ArrTime;
    public static int PassNumber;
    public static boolean twoWay;
    Menu menu = new Menu();
    ViewFlight bookresult = new ViewFlight();
    public Flights(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }
    @Override
    public void flightSearch() {

        Main.mainWindow.setTitle("Welcome To this page");
        GridPane gridPane = new GridPane();
        // gridPane set
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(20);
        gridPane.setHgap(20);
        gridPane.setPadding(new Insets(20));

        //PageTitle
        Text FlightText = new Text("Flight Search:");
        FlightText.setFill(Paint.valueOf("#dd877a"));
        FlightText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,25));
        gridPane.add(FlightText, 0,0);

        //departureCity
        Label departureCityLabel = new Label("departure City: ");
        departureCityLabel.setId("text");
        departureCityLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(departureCityLabel, 0, 1);
        TextField departureCityInput = new TextField();
        gridPane.add(departureCityInput, 1,1,3,1);

        //arrivalCity
        Label arrivalCityLabel = new Label("Arrival City: ");
        arrivalCityLabel.setId("text");
        arrivalCityLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(arrivalCityLabel, 0, 2);
        TextField arrivalCityInput = new TextField();
        gridPane.add(arrivalCityInput, 1,2,3,1);

        //departureDate
        Text departureDateText = new Text("Departure Date: ");
        departureDateText.setFill(Paint.valueOf("#282016"));
        departureDateText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(departureDateText, 0,3);
        checkInDatePickerDeparture = new DatePicker();
        gridPane.add(checkInDatePickerDeparture, 1, 3);

        //arrivalDate
        Text arrivalDateText = new Text("Arrival Date: ");
        arrivalDateText.setFill(Paint.valueOf("#282016"));
        arrivalDateText.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(arrivalDateText, 2,3);
        checkInDatePickerArrival = new DatePicker();
        gridPane.add(checkInDatePickerArrival, 3, 3);

        //PassengerNumber
        Label passengerNumberLabel = new Label("Number Of Passengers: ");
        passengerNumberLabel.setId("text");
        passengerNumberLabel.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        gridPane.add(passengerNumberLabel, 0, 4);
        TextField passengerNumberInput = new TextField();
        gridPane.add(passengerNumberInput, 1,4);

        //Two way Flight
        HBox hBoxTwoWay = new HBox(5);
        hBoxTwoWay.setAlignment(Pos.BOTTOM_LEFT);
        Text TwoWayFlight = new Text("Two-way round-trip flight");
        TwoWayFlight.setFont(Font.font("Tahoma", FontWeight.SEMI_BOLD,15));
        TwoWayFlight.setFill(Paint.valueOf("#282016"));
        CheckBox TwoWay = new CheckBox("");
        hBoxTwoWay.getChildren().addAll(TwoWayFlight, TwoWay);
        gridPane.add(hBoxTwoWay, 2,4);

        //Button
        HBox hBox = new HBox(20);
        hBox.setAlignment(Pos.CENTER);
        Button SearchFlight = new Button("Search Flight");
        SearchFlight.setPrefWidth(200);
        SearchFlight.setPrefHeight(40);
        SearchFlight.setId("btn_login" + "");
        Button BackMenu = new Button("Back To Menu");
        BackMenu.setPrefWidth(200);
        BackMenu.setPrefHeight(40);
        BackMenu.setId("btn_login");
        hBox.getChildren().addAll(BackMenu, SearchFlight);
        gridPane.add(hBox,0,5,4,1);
        BackMenu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                menu.SceneViewMenu();
            }
        });
        SearchFlight.setOnAction(new EventHandler<ActionEvent>() {

            String errorMessage = "";
            @Override
            public void handle(ActionEvent event) {
                if(departureCityInput.getText().equals("")){
                    errorMessage += "For flight search please fill departure Field!\n";
                }
                if(arrivalCityInput.getText().equals("")){
                    errorMessage += "For flight search please fill arrival Field!\n";
                }
                if(checkInDatePickerArrival.getValue().equals("")){
                    errorMessage += "For flight search please fill Date Field!\n";
                }
                if(!errorMessage.equals("")) AlertBox.display("Error", errorMessage);
                else if(searchResult(departureCityInput, arrivalCityInput, checkInDatePickerDeparture, checkInDatePickerArrival, passengerNumberInput, TwoWay)){
                    AlertBox.display("Success", "Mrs/Mr "+SignIn.UserLastName+" Please Wait!");
                    DepCity = departureCityInput.getText();
                    ArrCity = arrivalCityInput.getText();
                    DepDate = checkInDatePickerDeparture.getValue();
                    ArrDate = checkInDatePickerArrival.getValue();
                    PassNumber = Integer.parseInt( passengerNumberInput.getText());
                    twoWay = TwoWay.isSelected();
                    bookresult.start();
                }
            }
        });
        //Set scene
        Scene scene = new Scene(gridPane, 700, 500);
        scene.getStylesheets().add(FlightSearch.class.getResource("Search.css").toExternalForm());
        Main.mainWindow.setScene(scene);
        Main.mainWindow.show();
    }
    private boolean searchResult(TextField deCity, TextField arCity, DatePicker date1, DatePicker date2, TextField num, CheckBox TwoWey){
        return true;
    }
}
abstract class resultSearch implements FlightSearch{
    protected FlightSearch flightSe;
    public resultSearch(FlightSearch flightSe){
        this.flightSe = flightSe;
    }
    public void flightSearch(){
        this.flightSe.flightSearch();
    }
}
//class Search extends resultSearch{
//
//    public Search(FlightSearch flightSe) {
//        super(flightSe);
//    }
//    public void flightSearch(){
//
//          this.flightSe.flightSearch();
//          this.initialize();
//    }
//    public void initialize(){
//        final int[] Hour = new int[1];
//        int Minute;
//        final int[] Second = {new int[1]};
//        Thread clock = new Thread() {
//            public void run() {
//                for (;;) {
//                    DateFormat dateFormat = new SimpleDateFormat("hh:mm a");
//                    Calendar cal = Calendar.getInstance();
//
//                    Second[0] = cal.get(Calendar.SECOND);
//                    minute = cal.get(Calendar.MINUTE);
//                    hour = cal.get(Calendar.HOUR);
//                    //System.out.println(hour + ":" + (minute) + ":" + second);
//                    time.setText(hour + ":" + (minute) + ":" + second);
//
//                    try {
//                        sleep(1000);
//                    } catch (InterruptedException ex) {
//                        
//                    }
//                }
//            }
//        };
//        clock.start();
//    }
//}

