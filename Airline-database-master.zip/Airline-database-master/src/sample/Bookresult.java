package sample;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import sample.Test.INFORMATION;
import java.sql.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

class ViewFlight extends BorderPane{
    Menu menu = new Menu();
    SignIn signIn = new SignIn();
    Controller controller = new Controller();
    private Connection mySqlConnection;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    private static Stage mainWindow = null;
    private static int flightID = 0;
    static Scene flightResultContScene;
    TableView<INFORMATION> flightTable;
    public ViewFlight (){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.mySqlConnection = DriverManager.
                    getConnection("jdbc:mysql://localhost/flight_reservation?user=root&password=");
            this.statement = mySqlConnection.createStatement();
        }catch (ClassNotFoundException | SQLException e ){
            e.printStackTrace();
        }
    }
    public void start(){
        Label airlineLabel = new Label();
        airlineLabel.setFont(new Font(18));
        airlineLabel.setText("Arline Name");


        TextField airlineInput = new TextField();
        airlineInput.setPromptText("Airline Name");
        airlineInput.setPrefWidth(200);

        Button submit = new Button("SUBMIT");
        submit.setPrefWidth(100);


        Label menuLabel = new Label();
        menuLabel.setText("Flight List");
        menuLabel.setFont(new Font(25));
        menuLabel.setPadding(new Insets(0,0,10,0));

        TableColumn<INFORMATION, String> airlineName = new TableColumn<>("Airline");
        airlineName.setMinWidth(100);
        airlineName.setCellValueFactory(new PropertyValueFactory<>("airlineName"));

        TableColumn<INFORMATION, String> departureDate = new TableColumn<>("Depart Date");
        departureDate.setMinWidth(100);
        departureDate.setCellValueFactory(new PropertyValueFactory<>("departDate"));

        TableColumn<INFORMATION, String> departureTime = new TableColumn<>("Depart Time");
        departureTime.setMinWidth(90);
        departureTime.setCellValueFactory(new PropertyValueFactory<>("departureTime"));

        TableColumn<INFORMATION, Button> action = new TableColumn<>("Action");
        action.setMinWidth(110);
        action.setCellValueFactory(new PropertyValueFactory<>("action"));

        TableColumn<INFORMATION, String> arrivalTime = new TableColumn<>("Arrive Time");
        arrivalTime.setMinWidth(90);
        arrivalTime.setCellValueFactory(new PropertyValueFactory<>("arrivalTime"));


        flightTable = new TableView<>();
        flightTable.setPlaceholder(new Label("No flight found"));
        flightTable.getColumns().addAll(departureDate, departureTime, arrivalTime, airlineName, action);
        VBox vBox = new VBox();


        Button backButton = new Button("BACK");
        backButton.setPrefWidth(100);
        backButton.setPrefHeight(35);
        backButton.setId("button");
        backButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                menu.SceneViewMenu();
            }
        });

        Button cancelButton = new Button("CANCEL SELECTED FLIGHT");
        cancelButton.setPrefWidth(200);
        cancelButton.setPrefHeight(35);
        cancelButton.setId("button");

        HBox hBox = new HBox(5);
        hBox.setAlignment(Pos.CENTER);
        hBox.getChildren().addAll(backButton, cancelButton);

        setCenter(vBox);
        setAlignment(vBox, Pos.CENTER);
        setMargin(vBox, new Insets(0,20,0,20));

        vBox.getChildren().addAll(menuLabel, flightTable, hBox);

        Main.mainWindow.setTitle("Book Flight ");
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        Scene scene = new Scene(grid, 950, 500);
        grid.add(menuLabel, 0, 0,4,1);
        grid.add(flightTable, 0, 1, 4,1);
        grid.add(hBox, 0,2,4,1);
        setMargin(grid, new Insets(0,20,20,10));
        /*=======================================================================================
        =========================================================================================
         */
        try{
            this.preparedStatement = this.mySqlConnection.prepareStatement("SELECT * FROM flight WHERE " +
                    "departureCity = ? AND arrivalCity = ?");
           this.preparedStatement.setString(1, Flights.DepCity);
           this.preparedStatement.setString(2,Flights.ArrCity);
            this.resultSet = this.preparedStatement.executeQuery();

            while (resultSet.next()){
                Button btnSelect = new Button("Select");
                btnSelect.setPrefWidth(100);
                btnSelect.setId("button");
                btnSelect.setUserData(resultSet.getInt(1));
                btnSelect.setOnAction(new EventHandler<ActionEvent>() {
                    String errorMessage = "";
                    @Override
                    public void handle(ActionEvent event) {
                       Controller.display("select", Flights.ArrCity);
                    }
                });
                flightTable.getItems().add(

                        new INFORMATION(resultSet.getDate(4), resultSet.getTime(5)
                                , resultSet.getTime(9) , resultSet.getString(3), btnSelect)
                );
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        /*=====================================================
        ===============================================================================
         */
        ViewFlight viewFlight = new ViewFlight();
        Main.mainWindow.setScene(scene);
        scene.getStylesheets().add(ViewFlight.class.getResource("BookResult.css").toExternalForm());
        // bootstrap the stage
        Main.mainWindow.show();
    }
}