package sample.Test;
import java.awt.*;
import java.sql.Date;

public class cancel {
    private String departureCity;
    private String arrivalCity;
    private Date arrivalDate;
    private int price;
    private javafx.scene.control.Button button;

    public cancel(String departureCity, String arrivalCity, Date arrivalDate, int price, javafx.scene.control.Button btnCancel){
        this.departureCity = departureCity;
        this.arrivalCity = arrivalCity;
        this.arrivalDate = arrivalDate;
        this.price = price;
        this.button = btnCancel;
    }


    public String getDepartureCity(){return this.departureCity;}

    public String getArrivalCity(){return this.arrivalCity;}

    public Date getArrivalDate(){return this.arrivalDate;}

    public int getPrice(){return this.price;}

    public javafx.scene.control.Button getAction(){return this.button;}

}
