package sample.Test;

import javafx.scene.control.Button;

public class passenger {
        private String SeatNumber;
        private String fistName;
        private String lastName;

        public passenger(String SeatNumber, String fistName, String lastName){
            this.SeatNumber = SeatNumber;
            this.fistName = fistName;
            this.lastName = lastName;

        }

        public void setSeatNumber(String SeatNumber){this.SeatNumber = SeatNumber;}

        public String getSeatNumber(){return this.SeatNumber;}

        public void setFistName(String fistName){this.fistName = fistName;}

        public String getFistName(){return this.fistName;}

        public void setLastName(String lastName){this.lastName = lastName;}

        public String getLastName(){return this.lastName;}

}
