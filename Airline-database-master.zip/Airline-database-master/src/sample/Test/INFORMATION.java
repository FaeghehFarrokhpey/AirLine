package sample.Test;

//import java.awt.*;
import javafx.scene.control.Button;

import java.sql.Date;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class INFORMATION  {

    private String airlineName;
    private Date departureDate;
    private Time departureTime;
    private Time arrivalTime;
    private Button button;

    public INFORMATION ( Date departureDate, Time departureTime, Time arrivalTime,  String airlineName, Button btn) {

      this.airlineName = airlineName;
      this.departureTime = departureTime;
      this.departureDate = departureDate;
      this.arrivalTime = arrivalTime;
      this.button = btn;
    }

    public Time getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(Time departureTime) {
        this.departureTime = departureTime;
    }

    public Date getDepartDate() { return departureDate; }

    public void setDepartureDate(Date departureDate){ this.departureDate = departureDate; }

    public Button getAction () {
        return this.button;
    }

    public Time getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(Time arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getAirlineName() {
        return airlineName;
    }

    public void setAirlineName(String airlineName) {
        this.airlineName = airlineName;
    }

    public String convertTime(String time) {
        String ampmTime = "";
        DateFormat f1 = new SimpleDateFormat("HH:mm:ss"); //HH for hour of the day (0 - 23)
        Date d;
        try {
            d = (Date) f1.parse(time);
            DateFormat f2 = new SimpleDateFormat("h:mma");
            ampmTime = f2.format(d).toUpperCase(); // "12:18AM"
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return ampmTime;

    }

}
